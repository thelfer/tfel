First, compute the tensors (the polycrystal must be stored in a file "polycrystal.npy"):

python3 HS_tensors.py

It will store the coefficients Gamma_rs in a file "Grs.npy". Second,
just do 

python3 write_C.py

it will write the header. Just be careful to the reference medium
`L0` in `HS_tensors.py` as in `write_C.py`.
