##type: ignore
import numpy as np
from numba import njit, prange, jit, set_num_threads
import sys
from Operators import *
import matplotlib.pyplot as plt

d = 6
I = np.eye(d)
J = np.zeros((d, d))
J[:3, :3] = 1.0 / 3.0
K = I - J


@njit(parallel=True)
def initialize_tau(field, N, dim, NN, j):
    tau_i = np.zeros((6,))
    tau_i[j] = 1.0
    for i in prange(NN):
        n = compute_n(i, N, dim)
        field[n[0], n[1], n[2]] = tau_i


@njit(parallel=True)
def update_field(micro, field, N, dim, NN, r):
    for i in prange(NN):
        n = compute_n(i, N, dim)
        chi_ = micro[n[0], n[1], n[2]]
        fac=0
        if chi_==r:
            fac=1
        field[n[0], n[1], n[2]] = fac * field[n[0], n[1], n[2]]


def compute_interaction_matrix(micro, Cref, N, NN, nph):
    L = [1, 1, 1]
    d = 6
    dim = 3
    field = np.zeros(tuple(N) + (d,))
    phases = np.zeros((nph, NN))
    chi_flat = micro.flatten()
    frac= np.zeros((nph,))
    for i in range(NN):
        j = chi_flat[i]
        frac[j]+=1/NN
        for r in range(nph):
            if r == j:
                phases[r, i] = 1
    print(frac)
    Grs=np.zeros((nph,nph,d,d))
    print("initialize Gamma")
    Gamma_field = np.zeros(tuple(N) + (d, d), dtype=np.complex128)
    initialize_Gamma(Cref, N, L, dim, NN, Gamma_field,"Willot")
    for j in range(d):
        print("compute component " + str(j))
        for s in range(nph):
            print("phase ",s)
            initialize_tau(field, N, dim, NN, j)
            update_field(micro, field, N, dim, NN, s)
            field = Fourier_convolution(field,Gamma_field,dim,N,NN)
            field = field.astype("float64")
            field_resh=field.reshape(NN,d)
            for r in range(nph):
            	print("average on phase ",r)
            	Grsj = np.einsum('ij,i->ij',field_resh,phases[r])
            	Grsj = np.mean(Grsj,axis=0)/frac[r]
            	Grs[r,s,:,j]=Grsj
    return Grs
   
micro=np.load("polycrystal.npy")
N=micro.shape
NN=N[0]*N[1]*N[2]
print(N)
nph=1+max(micro.reshape((NN,)))
print(nph)
ka = 0
mu = 1
L0 = 3 * ka * J + 2 * mu * K
Grs=compute_interaction_matrix(micro,L0,N, NN, nph)
np.save("Grs.npy",Grs)
