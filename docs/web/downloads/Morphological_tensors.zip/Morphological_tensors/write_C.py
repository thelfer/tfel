##type: ignore

import numpy as np

d = 6
I = np.eye(d)
J = np.zeros((d, d))
J[:3, :3] = 1.0 / 3.0
K = I - J

def write_C(tensor, name, nr):
    file.write("template<tfel::math::ScalarConcept real> struct " + name + "{" + "\n")
    file.write("static const std::array<std::array<tfel::math::st2tost2<3u,real>,"+str(nr)+">,"+str(nr)+">& get_tensor(){" + "\n")
    file.write("static " + name + " " + name + "_;" + "\n")
    file.write("return " + name + "_.tensor;}" + "\n")
    file.write("std::array<std::array<tfel::math::st2tost2<3u,real>,"+str(nr)+">,"+str(nr)+"> tensor;" + "\n")
    file.write("private:" + "\n")
    file.write(name + "(){" + "\n")

    for ii in range(nr):
        for jj in range(nr):
            file.write("this->tensor["+str(ii)+"]["+str(jj)+"] = {")
            for i in range(6):
                file.write("{")
                for j in range(6):
                    el = tensor[ii,jj,i,j]
                    file.write(str(el))
                    if j != 5:
                        file.write(",")
                file.write("}")
                if i != 5:
                    file.write(",")
            file.write("};" + "\n")

    file.write("}};" + "\n" + "\n")


ka = 0
mu = 1
L0 = 3 * ka * J + 2 * mu * K

Gamma = np.load("Grs.npy")
sh=Gamma.shape
print(sh)
Delta=np.zeros(sh)
nr=sh[0]
for r in range(nr):
	for s in range(nr):
		if r==s:
			delta=1
		else:
			delta=0
		Delta[r,s]=L0*delta-np.dot(L0,np.dot(Gamma[r,s],L0))
		

file = open("extra-headers/TFEL/Material/tensors.hxx", "w")
file.write("#ifndef LIB_TFEL_MATERIAL_TENSORS_HXX" + "\n")
file.write("#define LIB_TFEL_MATERIAL_TENSORS_HXX" + "\n")

write_C(Delta, "Delta",nr)
write_C(Gamma, "Gamma",nr)

file.write("#endif /* LIB_TFEL_MATERIAL_TENSORS_HXX */" + "\n")
